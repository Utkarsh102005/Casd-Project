"use client"

import { useState } from "react"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, LinkIcon, AlertCircle, CheckCircle, Loader2 } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function ScannerPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("file")
  const [isScanning, setIsScanning] = useState(false)
  const [scanProgress, setScanProgress] = useState(0)
  const [scanResult, setScanResult] = useState(null)
  const [file, setFile] = useState(null)
  const [url, setUrl] = useState("")

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
      setScanResult(null)
    }
  }

  const handleUrlChange = (e) => {
    setUrl(e.target.value)
    setScanResult(null)
  }

  const simulateScanProgress = () => {
    setScanProgress(0)
    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 5
      })
    }, 200)

    return interval
  }

  const scanFile = async () => {
    if (!file) {
      toast({
        title: "No File Selected",
        description: "Please select a file to scan.",
        variant: "destructive",
      })
      return
    }

    setIsScanning(true)
    setScanResult(null)

    const progressInterval = simulateScanProgress()

    try {
      // Create form data for file upload
      const formData = new FormData()
      formData.append("file", file)

      // Send to API
      const response = await fetch("/api/scan-file", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error("Failed to scan file")
      }

      const data = await response.json()

      // Ensure progress is at 100% before showing results
      setScanProgress(100)

      setTimeout(() => {
        setScanResult({
          safe: data.safe,
          threatType: data.threatType,
          detectionCount: data.detectionCount,
          scanDate: new Date().toISOString(),
          fileName: file.name,
          fileSize: file.size,
          message: data.message,
        })
        setIsScanning(false)
      }, 500)
    } catch (error) {
      console.error("Error scanning file:", error)
      toast({
        title: "Scan Failed",
        description: "There was an error scanning your file. Please try again.",
        variant: "destructive",
      })
      setIsScanning(false)
    } finally {
      clearInterval(progressInterval)
    }
  }

  const scanUrl = async () => {
    if (!url) {
      toast({
        title: "No URL Entered",
        description: "Please enter a URL to scan.",
        variant: "destructive",
      })
      return
    }

    // Basic URL validation
    if (!url.match(/^(http|https):\/\/[^ "]+$/)) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid URL including http:// or https://",
        variant: "destructive",
      })
      return
    }

    setIsScanning(true)
    setScanResult(null)

    const progressInterval = simulateScanProgress()

    try {
      // Send to API
      const response = await fetch("/api/scan-url", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url }),
      })

      if (!response.ok) {
        throw new Error("Failed to scan URL")
      }

      const data = await response.json()

      // Ensure progress is at 100% before showing results
      setScanProgress(100)

      setTimeout(() => {
        setScanResult({
          safe: data.safe,
          threatType: data.threatType,
          scanDate: new Date().toISOString(),
          url: url,
          message: data.message,
        })
        setIsScanning(false)
      }, 500)
    } catch (error) {
      console.error("Error scanning URL:", error)
      toast({
        title: "Scan Failed",
        description: "There was an error scanning the URL. Please try again.",
        variant: "destructive",
      })
      setIsScanning(false)
    } finally {
      clearInterval(progressInterval)
    }
  }

  return (
    <div className="container max-w-4xl py-12">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Threat Scanner</h1>
          <p className="text-gray-500 mt-2">Scan files and URLs to check for malware, phishing, and other threats.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Security Scanner</CardTitle>
            <CardDescription>Our scanner uses multiple security engines to detect threats.</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="file" onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="file">Scan File</TabsTrigger>
                <TabsTrigger value="url">Scan URL</TabsTrigger>
              </TabsList>
              <TabsContent value="file" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="file-upload">Select File to Scan</Label>
                  <div className="flex items-center gap-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById("file-upload").click()}
                      className="w-full"
                      disabled={isScanning}
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      {file ? file.name : "Choose File"}
                    </Button>
                  </div>
                  <Input
                    id="file-upload"
                    type="file"
                    className="hidden"
                    onChange={handleFileChange}
                    disabled={isScanning}
                  />
                  <p className="text-xs text-gray-500">
                    Max file size: 32MB. Supported formats: Documents, Images, Archives, Executables
                  </p>
                </div>
                <Button onClick={scanFile} className="w-full" disabled={!file || isScanning}>
                  {isScanning ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Scanning...
                    </>
                  ) : (
                    "Scan File"
                  )}
                </Button>
              </TabsContent>
              <TabsContent value="url" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="url-input">Enter URL to Scan</Label>
                  <div className="flex items-center gap-2">
                    <div className="relative w-full">
                      <LinkIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="url-input"
                        placeholder="https://example.com"
                        className="pl-10"
                        value={url}
                        onChange={handleUrlChange}
                        disabled={isScanning}
                      />
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">Enter the complete URL including http:// or https://</p>
                </div>
                <Button onClick={scanUrl} className="w-full" disabled={!url || isScanning}>
                  {isScanning ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Scanning...
                    </>
                  ) : (
                    "Scan URL"
                  )}
                </Button>
              </TabsContent>
            </Tabs>

            {isScanning && (
              <div className="mt-6 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Scanning in progress...</span>
                  <span>{scanProgress}%</span>
                </div>
                <Progress value={scanProgress} className="h-2" />
              </div>
            )}

            {scanResult && (
              <div className="mt-6">
                <Alert variant={scanResult.safe ? "default" : "destructive"}>
                  {scanResult.safe ? <CheckCircle className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                  <AlertTitle>{scanResult.safe ? "No Threats Detected" : "Threat Detected"}</AlertTitle>
                  <AlertDescription>{scanResult.message}</AlertDescription>
                </Alert>

                <div className="mt-4 border rounded-md p-4 space-y-3">
                  <h3 className="font-medium">Scan Details</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-gray-500">Scan Date:</div>
                    <div>{new Date(scanResult.scanDate).toLocaleString()}</div>

                    {activeTab === "file" && (
                      <>
                        <div className="text-gray-500">File Name:</div>
                        <div>{scanResult.fileName}</div>

                        <div className="text-gray-500">File Size:</div>
                        <div>{Math.round(scanResult.fileSize / 1024)} KB</div>
                      </>
                    )}

                    {activeTab === "url" && (
                      <>
                        <div className="text-gray-500">URL:</div>
                        <div className="truncate">{scanResult.url}</div>
                      </>
                    )}

                    <div className="text-gray-500">Status:</div>
                    <div className={scanResult.safe ? "text-green-600" : "text-red-600"}>
                      {scanResult.safe ? "Safe" : "Unsafe"}
                    </div>

                    {!scanResult.safe && (
                      <>
                        <div className="text-gray-500">Threat Type:</div>
                        <div>{scanResult.threatType}</div>

                        {scanResult.detectionCount && (
                          <>
                            <div className="text-gray-500">Detection Count:</div>
                            <div>{scanResult.detectionCount} engines</div>
                          </>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex flex-col space-y-2">
            <p className="text-xs text-gray-500 text-center">
              Powered by VirusTotal and Google Safe Browsing API. Results are for informational purposes only.
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
