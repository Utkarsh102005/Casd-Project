"use client"

import { useState } from "react"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Upload, MapPin, Send } from "lucide-react"
import { useRouter } from "next/navigation"

export default function ReportPage() {
  const { toast } = useToast()
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    scamType: "",
    description: "",
    contactInfo: "",
    attachFile: null,
    shareLocation: false,
    latitude: null,
    longitude: null,
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value) => {
    setFormData((prev) => ({ ...prev, scamType: value }))
  }

  const handleFileChange = (e) => {
    setFormData((prev) => ({ ...prev, attachFile: e.target.files[0] }))
  }

  const handleLocationToggle = (checked) => {
    setFormData((prev) => ({ ...prev, shareLocation: checked }))

    if (checked) {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setFormData((prev) => ({
              ...prev,
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
            }))
          },
          (error) => {
            console.error("Error getting location:", error)
            toast({
              title: "Location Error",
              description: "Unable to get your location. Please try again or enter manually.",
              variant: "destructive",
            })
          },
        )
      } else {
        toast({
          title: "Location Not Supported",
          description: "Geolocation is not supported by your browser.",
          variant: "destructive",
        })
      }
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Create form data for file upload
      const data = new FormData()
      data.append("scamType", formData.scamType)
      data.append("description", formData.description)
      data.append("contactInfo", formData.contactInfo)

      if (formData.attachFile) {
        data.append("file", formData.attachFile)
      }

      if (formData.shareLocation && formData.latitude && formData.longitude) {
        data.append("latitude", formData.latitude)
        data.append("longitude", formData.longitude)
      }

      // Submit to API
      const response = await fetch("/api/report", {
        method: "POST",
        body: data,
      })

      if (!response.ok) {
        throw new Error("Failed to submit report")
      }

      toast({
        title: "Report Submitted",
        description: "Thank you for helping keep others safe. Your report has been submitted successfully.",
      })

      // Redirect to thank you page or dashboard
      router.push("/report/thank-you")
    } catch (error) {
      console.error("Error submitting report:", error)
      toast({
        title: "Submission Failed",
        description: "There was an error submitting your report. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container max-w-4xl py-12">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Report a Scam</h1>
          <p className="text-gray-500 mt-2">
            Help protect others by reporting scams, fraud attempts, and suspicious activities.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Scam Report Form</CardTitle>
            <CardDescription>
              Please provide as much detail as possible to help us analyze and alert others.
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="scamType">Type of Scam</Label>
                <Select onValueChange={handleSelectChange} required>
                  <SelectTrigger id="scamType">
                    <SelectValue placeholder="Select scam type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="phishing">Phishing Email/Message</SelectItem>
                    <SelectItem value="vishing">Phone Call Scam (Vishing)</SelectItem>
                    <SelectItem value="smishing">SMS Scam (Smishing)</SelectItem>
                    <SelectItem value="impersonation">Impersonation/Fake Profile</SelectItem>
                    <SelectItem value="malware">Malware/Ransomware</SelectItem>
                    <SelectItem value="financial">Financial Fraud</SelectItem>
                    <SelectItem value="shopping">Online Shopping Scam</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  placeholder="Describe the scam in detail (what happened, how you were contacted, any suspicious links or phone numbers, etc.)"
                  rows={5}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="contactInfo">Contact Information (Optional)</Label>
                <Input
                  id="contactInfo"
                  name="contactInfo"
                  placeholder="Your email or phone number (for follow-up if needed)"
                  onChange={handleInputChange}
                />
                <p className="text-xs text-gray-500">
                  We'll only use this to contact you if we need more information about your report.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="file">Attach Evidence (Optional)</Label>
                <div className="flex items-center gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => document.getElementById("file").click()}
                    className="w-full"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    {formData.attachFile ? formData.attachFile.name : "Choose File"}
                  </Button>
                </div>
                <Input
                  id="file"
                  type="file"
                  className="hidden"
                  onChange={handleFileChange}
                  accept="image/*,.pdf,.doc,.docx,.txt,.eml"
                />
                <p className="text-xs text-gray-500">Upload screenshots, emails, or other evidence (Max size: 10MB)</p>
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="shareLocation" checked={formData.shareLocation} onCheckedChange={handleLocationToggle} />
                <Label htmlFor="shareLocation" className="flex items-center cursor-pointer">
                  <MapPin className="mr-2 h-4 w-4" />
                  Share your location (helps track scam patterns in your area)
                </Label>
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? (
                  "Submitting..."
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" /> Submit Report
                  </>
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  )
}
